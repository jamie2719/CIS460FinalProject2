#include "geometry.h"

Geometry::Geometry() {

}

